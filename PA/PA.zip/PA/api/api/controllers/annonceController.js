const { validationResult } = require('express-validator');
const Annonce = require('../models').Annonce;

const getAllAnnonces = async (req, res) => {
  try {
    const annonces = await Annonce.findAll();
    res.status(200).json(annonces);
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la récupération des annonces' });
  }
};

const getAnnonceById = async (req, res) => {
  try {
    const annonce = await Annonce.findByPk(req.params.id);
    if (!annonce) return res.status(404).json({ message: 'Annonce non trouvée' });
    res.status(200).json(annonce);
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la récupération de l’annonce' });
  }
};

const createAnnonce = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty())
    return res.status(400).json({ errors: errors.array() });

  const {
    Description,
    Type,
    IdTache,
    Temps,
    Prix,
    Debut,
    Fin,
    Pays,
    Titre,
    Statut,
    Adresse,
    DateSouhaitee,
    LienImage,
    IdCreateur
  } = req.body;

  try {
    const annonce = await Annonce.create({
      Description,
      Type,
      IdTache,
      Temps,
      Prix,
      Debut,
      Fin,
      Pays,
      Titre,
      Statut,
      Adresse,
      DateSouhaitee,
      LienImage,
      IdCreateur
    });
    res.status(201).json(annonce);
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la création de l’annonce' });
  }
};

const updateAnnonce = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty())
    return res.status(400).json({ errors: errors.array() });

  try {
    const [updated] = await Annonce.update(req.body, {
      where: { IdAnnonce: req.params.id }
    });

    if (!updated) return res.status(404).json({ message: 'Annonce non trouvée' });
    res.status(200).json({ message: 'Annonce mise à jour avec succès' });
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la mise à jour de l’annonce' });
  }
};

const patchAnnonce = async (req, res) => {
  try {
    const [updated] = await Annonce.update(req.body, {
      where: { IdAnnonce: req.params.id }
    });

    if (!updated) return res.status(404).json({ message: 'Annonce non trouvée' });
    res.status(200).json({ message: 'Annonce partiellement mise à jour' });
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la mise à jour partielle' });
  }
};

const deleteAnnonce = async (req, res) => {
  try {
    const deleted = await Annonce.destroy({ where: { IdAnnonce: req.params.id } });
    if (!deleted) return res.status(404).json({ message: 'Annonce non trouvée' });
    res.status(200).json({ message: 'Annonce supprimée avec succès' });
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la suppression de l’annonce' });
  }
};

module.exports = {
  getAllAnnonces,
  getAnnonceById,
  createAnnonce,
  updateAnnonce,
  patchAnnonce,
  deleteAnnonce
};