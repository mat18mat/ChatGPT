const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');
const Utilisateur = require('../models').Utilisateur;

const getAllUtilisateurs = async (req, res, next) => {
  try {
    const utilisateurs = await Utilisateur.findAll();
    res.status(200).json(utilisateurs);
  } catch (err) {
    next(err);
  }
};

const getUtilisateurById = async (req, res, next) => {
  try {
    const utilisateur = await Utilisateur.findByPk(req.params.id);
    if (!utilisateur) {
      return res.status(404).json({ message: 'Utilisateur non trouvé' });
    }
    res.status(200).json(utilisateur);
  } catch (err) {
    next(err);
  }
};

const createUtilisateur = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array().map(e => e.msg) });
  }

  try {
    const {
      Nom,
      Prenom,
      Mail,
      PieceIdentite,
      NoteMoyenne,
      Telephone,
      Mdp,
      Adresse,
      DateNaissance,
      DateInscription,
      LanguePreferee,
      TutorielVu,
      Banni,
      PhotoProfil,
      JustificatifDomicile,
      QRCode,
      IdRole
    } = req.body;

    const hash = await bcrypt.hash(Mdp, 10);

    const utilisateur = await Utilisateur.create({
      Nom,
      Prenom,
      Mail,
      PieceIdentite,
      NoteMoyenne,
      Telephone,
      Mdp: hash,
      Adresse,
      DateNaissance,
      DateInscription,
      LanguePreferee,
      TutorielVu,
      Banni,
      PhotoProfil,
      JustificatifDomicile,
      QRCode,
      IdRole
    });

    res.status(201).json(utilisateur);
  } catch (err) {
    next(err);
  }
};

const updateUtilisateur = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array().map(e => e.msg) });
  }

  try {
    if (req.body.Mdp) {
      req.body.Mdp = await bcrypt.hash(req.body.Mdp, 10);
    }

    const [updated] = await Utilisateur.update(req.body, {
      where: { IdUtilisateur: req.params.id }
    });
    if (!updated) {
      return res.status(404).json({ message: 'Utilisateur non trouvé' });
    }

    const utilisateur = await Utilisateur.findByPk(req.params.id);
    res.status(200).json(utilisateur);
  } catch (err) {
    next(err);
  }
};

const patchUtilisateur = async (req, res, next) => {
  try {
    if (req.body.Mdp) {
      req.body.Mdp = await bcrypt.hash(req.body.Mdp, 10);
    }

    const [updated] = await Utilisateur.update(req.body, {
      where: { IdUtilisateur: req.params.id }
    });
    if (!updated) {
      return res.status(404).json({ message: 'Utilisateur non trouvé' });
    }

    const utilisateur = await Utilisateur.findByPk(req.params.id);
    res.status(200).json(utilisateur);
  } catch (err) {
    next(err);
  }
};

const deleteUtilisateur = async (req, res, next) => {
  try {
    const deleted = await Utilisateur.destroy({
      where: { IdUtilisateur: req.params.id }
    });
    if (!deleted) {
      return res.status(404).json({ message: 'Utilisateur non trouvé' });
    }
    res.status(204).end();
  } catch (err) {
    next(err);
  }
};

const registerUtilisateur = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array().map(e => e.msg) });
  }

  try {
    const { Nom, Prenom, Mail, Mdp } = req.body;
    const hash = await bcrypt.hash(Mdp, 10);

    const user = await Utilisateur.create({
      Nom,
      Prenom,
      Mail,
      Mdp: hash,
      DateInscription: new Date()
    });

    const token = jwt.sign(
      { sub: user.IdUtilisateur },
      process.env.JWT_SECRET,
      { expiresIn: '2h' }
    );

    res.status(201).json({ token });
  } catch (err) {
    next(err);
  }
};

const loginUtilisateur = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ errors: errors.array().map(e => e.msg) });
  }

  try {
    const { mail, Mdp } = req.body;
    const utilisateur = await Utilisateur.findOne({
      where: { Mail: mail }
    });

    if (!utilisateur || !(await bcrypt.compare(Mdp, utilisateur.Mdp))) {
      return res.status(401).json({ message: 'Email ou mot de passe invalide' });
    }

    const token = jwt.sign(
      { sub: utilisateur.IdUtilisateur },
      process.env.JWT_SECRET,
      { expiresIn: '2h' }
    );

    res.json({ token });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getAllUtilisateurs,
  getUtilisateurById,
  createUtilisateur,
  updateUtilisateur,
  patchUtilisateur,
  deleteUtilisateur,
  registerUtilisateur,
  loginUtilisateur
};