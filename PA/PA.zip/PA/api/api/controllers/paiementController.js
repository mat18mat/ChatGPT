const { validationResult } = require('express-validator');
const Paiement = require('../models').Paiement;

const getAllPaiements = async (req, res) => {
  try {
    const paiements = await Paiement.findAll();
    res.status(200).json(paiements);
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la récupération des paiements' });
  }
};

const getPaiementById = async (req, res) => {
  try {
    const paiement = await Paiement.findByPk(req.params.id);
    if (!paiement) return res.status(404).json({ message: 'Paiement non trouvé' });
    res.status(200).json(paiement);
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la récupération du paiement' });
  }
};

const createPaiement = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty())
    return res.status(400).json({ errors: errors.array() });

  const {
    IdUtilisateur,
    Montant,
    TypePaiement,
    DatePaiement,
    Statut,
    IdFacture,
    IdMoyenPaiement
  } = req.body;

  try {
    const paiement = await Paiement.create({
      IdUtilisateur,
      Montant,
      TypePaiement,
      DatePaiement,
      Statut,
      IdFacture,
      IdMoyenPaiement
    });
    res.status(201).json(paiement);
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la création du paiement' });
  }
};

const updatePaiement = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty())
    return res.status(400).json({ errors: errors.array() });

  try {
    const [updated] = await Paiement.update(req.body, {
      where: { IdPaiement: req.params.id }
    });

    if (!updated) return res.status(404).json({ message: 'Paiement non trouvé' });
    res.status(200).json({ message: 'Paiement mis à jour avec succès' });
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la mise à jour' });
  }
};

const patchPaiement = async (req, res) => {
  try {
    const [updated] = await Paiement.update(req.body, {
      where: { IdPaiement: req.params.id }
    });

    if (!updated) return res.status(404).json({ message: 'Paiement non trouvé' });
    res.status(200).json({ message: 'Paiement mis à jour partiellement' });
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la mise à jour partielle' });
  }
};

const deletePaiement = async (req, res) => {
  try {
    const deleted = await Paiement.destroy({ where: { IdPaiement: req.params.id } });
    if (!deleted) return res.status(404).json({ message: 'Paiement non trouvé' });
    res.status(200).json({ message: 'Paiement supprimé avec succès' });
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la suppression' });
  }
};

module.exports = {
  getAllPaiements,
  getPaiementById,
  createPaiement,
  updatePaiement,
  patchPaiement,
  deletePaiement
};