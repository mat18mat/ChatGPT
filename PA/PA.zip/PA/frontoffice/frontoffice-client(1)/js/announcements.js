// Gestion des annonces
let announcements = []
let currentPage = 1
let totalPages = 1
let filters = {}

// Déclaration des variables manquantes
const API_BASE_URL = "https://your-api-base-url.com" // Remplacez par l'URL de base de votre API
const authToken = "your-auth-token" // Remplacez par votre token d'authentification

// Déclarations des fonctions manquantes (à adapter selon votre projet)
function getCurrentPage() {
  // Retourne la page actuelle (ex: en lisant l'URL)
  return window.location.pathname.split("/").pop()
}

async function apiCall(endpoint, options = {}) {
  // Simule un appel API
  const url = API_BASE_URL + endpoint
  const headers = {
    "Content-Type": "application/json",
    Authorization: `Bearer ${authToken}`,
    ...options.headers,
  }

  const config = {
    ...options,
    headers,
  }

  const response = await fetch(url, config)

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`)
  }

  return await response.json()
}

function showNotification(message, type = "info") {
  // Affiche une notification (ex: en haut de la page)
  alert(`${type.toUpperCase()}: ${message}`)
}

function formatDate(dateString) {
  const date = new Date(dateString)
  return date.toLocaleDateString("fr-FR")
}

function formatPrice(price) {
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(price)
}

// Initialisation
document.addEventListener("DOMContentLoaded", () => {
  if (getCurrentPage() === "annonces") {
    initializeAnnouncementsPage()
  }
})

async function initializeAnnouncementsPage() {
  await loadAnnouncements()
  initializeAnnouncementEventListeners()
}

function initializeAnnouncementEventListeners() {
  // Formulaire de création/édition
  const form = document.getElementById("announcement-form")
  if (form) {
    form.addEventListener("submit", handleAnnouncementSubmit)
  }

  // Filtres
  const filterInputs = ["filter-status", "filter-type", "filter-date"]
  filterInputs.forEach((id) => {
    const element = document.getElementById(id)
    if (element) {
      element.addEventListener("change", applyFilters)
    }
  })
}

// Charger les annonces
async function loadAnnouncements(page = 1) {
  try {
    const queryParams = new URLSearchParams({
      page: page,
      limit: 10,
      ...filters,
    })

    const response = await apiCall(`/announcements?${queryParams}`)

    announcements = response.data || []
    currentPage = response.currentPage || 1
    totalPages = response.totalPages || 1

    displayAnnouncements()
    updatePagination()
  } catch (error) {
    console.error("Erreur lors du chargement des annonces:", error)
    showNotification("Erreur lors du chargement des annonces", "error")
  }
}

// Afficher les annonces
function displayAnnouncements() {
  const container = document.getElementById("announcements-list")
  if (!container) return

  if (announcements.length === 0) {
    container.innerHTML = `
            <div class="text-center py-12">
                <i class="fas fa-inbox text-gray-400 text-6xl mb-4"></i>
                <h3 class="text-xl font-semibold text-gray-600 mb-2">Aucune annonce trouvée</h3>
                <p class="text-gray-500 mb-6">Créez votre première annonce pour commencer</p>
                <button onclick="openCreateModal()" class="bg-primary text-white px-6 py-3 rounded-lg hover:bg-secondary transition-colors">
                    Créer une annonce
                </button>
            </div>
        `
    return
  }

  container.innerHTML = announcements.map((announcement) => createAnnouncementCard(announcement)).join("")
}

// Créer une carte d'annonce
function createAnnouncementCard(announcement) {
  const statusClass = getStatusClass(announcement.status)
  const statusText = getStatusText(announcement.status)

  return `
        <div class="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
            <div class="flex justify-between items-start mb-4">
                <div class="flex-1">
                    <div class="flex items-center space-x-3 mb-2">
                        <h3 class="text-xl font-semibold text-gray-900">${announcement.title}</h3>
                        <span class="px-3 py-1 rounded-full text-sm font-medium ${statusClass}">
                            ${statusText}
                        </span>
                    </div>
                    <p class="text-gray-600 mb-3">${announcement.description}</p>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                        <div class="flex items-center">
                            <i class="fas fa-map-marker-alt text-primary mr-2"></i>
                            <span>De: ${announcement.pickup_address}</span>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-map-marker-alt text-secondary mr-2"></i>
                            <span>À: ${announcement.delivery_address}</span>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-calendar text-primary mr-2"></i>
                            <span>${formatDate(announcement.preferred_date)}</span>
                        </div>
                        <div class="flex items-center">
                            <i class="fas fa-euro-sign text-primary mr-2"></i>
                            <span>${announcement.price ? formatPrice(announcement.price) : "Prix à négocier"}</span>
                        </div>
                    </div>
                </div>
                
                <div class="flex flex-col space-y-2 ml-4">
                    ${createAnnouncementActions(announcement)}
                </div>
            </div>
            
            ${announcement.provider ? createProviderInfo(announcement.provider) : ""}
            ${announcement.offers && announcement.offers.length > 0 ? createOffersSection(announcement.offers) : ""}
        </div>
    `
}

// Créer les actions pour une annonce
function createAnnouncementActions(announcement) {
  let actions = ""

  switch (announcement.status) {
    case "pending":
      actions = `
        <button onclick="editAnnouncement('${announcement.id}')" class="text-blue-600 hover:text-blue-800 p-2 rounded-lg hover:bg-blue-50 transition-colors">
          <i class="fas fa-edit mr-1"></i> Modifier
        </button>
        <button onclick="cancelAnnouncement('${announcement.id}')" class="text-red-600 hover:text-red-800 p-2 rounded-lg hover:bg-red-50 transition-colors">
          <i class="fas fa-times mr-1"></i> Annuler
        </button>
        <button onclick="viewOffers('${announcement.id}')" class="text-green-600 hover:text-green-800 p-2 rounded-lg hover:bg-green-50 transition-colors">
          <i class="fas fa-eye mr-1"></i> Voir offres
        </button>
      `
      break
    case "accepted":
      actions = `
        <button onclick="viewProvider('${announcement.provider_id}')" class="text-blue-600 hover:text-blue-800 p-2 rounded-lg hover:bg-blue-50 transition-colors">
          <i class="fas fa-user mr-1"></i> Prestataire
        </button>
        <button onclick="trackDelivery('${announcement.id}')" class="text-purple-600 hover:text-purple-800 p-2 rounded-lg hover:bg-purple-50 transition-colors">
          <i class="fas fa-map-marker-alt mr-1"></i> Suivre
        </button>
        <button onclick="cancelAnnouncement('${announcement.id}')" class="text-red-600 hover:text-red-800 p-2 rounded-lg hover:bg-red-50 transition-colors">
          <i class="fas fa-times mr-1"></i> Annuler
        </button>
      `
      break
    case "in_progress":
      actions = `
        <button onclick="trackDelivery('${announcement.id}')" class="text-purple-600 hover:text-purple-800 p-2 rounded-lg hover:bg-purple-50 transition-colors">
          <i class="fas fa-map-marker-alt mr-1"></i> Suivre en temps réel
        </button>
        <button onclick="contactProvider('${announcement.provider_id}')" class="text-blue-600 hover:text-blue-800 p-2 rounded-lg hover:bg-blue-50 transition-colors">
          <i class="fas fa-phone mr-1"></i> Contacter
        </button>
      `
      break
    case "completed":
      const hasRating = announcement.rating && announcement.rating.id
      if (hasRating) {
        actions = `
          <button onclick="viewRating('${announcement.rating.id}')" class="text-yellow-600 hover:text-yellow-800 p-2 rounded-lg hover:bg-yellow-50 transition-colors">
            <i class="fas fa-star mr-1"></i> Voir ma note
          </button>
          <button onclick="downloadInvoice('${announcement.id}')" class="text-green-600 hover:text-green-800 p-2 rounded-lg hover:bg-green-50 transition-colors">
            <i class="fas fa-download mr-1"></i> Facture
          </button>
          <button onclick="reorderService('${announcement.id}')" class="text-primary hover:text-secondary p-2 rounded-lg hover:bg-primary/10 transition-colors">
            <i class="fas fa-redo mr-1"></i> Recommander
          </button>
        `
      } else {
        actions = `
          <button onclick="rateService('${announcement.id}')" class="text-yellow-600 hover:text-yellow-800 p-2 rounded-lg hover:bg-yellow-50 transition-colors animate-pulse">
            <i class="fas fa-star mr-1"></i> Noter le service
          </button>
          <button onclick="downloadInvoice('${announcement.id}')" class="text-green-600 hover:text-green-800 p-2 rounded-lg hover:bg-green-50 transition-colors">
            <i class="fas fa-download mr-1"></i> Facture
          </button>
          <button onclick="reorderService('${announcement.id}')" class="text-primary hover:text-secondary p-2 rounded-lg hover:bg-primary/10 transition-colors">
            <i class="fas fa-redo mr-1"></i> Recommander
          </button>
        `
      }
      break
    case "cancelled":
      actions = `
        <button onclick="reorderService('${announcement.id}')" class="text-primary hover:text-secondary p-2 rounded-lg hover:bg-primary/10 transition-colors">
          <i class="fas fa-redo mr-1"></i> Recréer
        </button>
        <button onclick="viewCancellationReason('${announcement.id}')" class="text-gray-600 hover:text-gray-800 p-2 rounded-lg hover:bg-gray-50 transition-colors">
          <i class="fas fa-info-circle mr-1"></i> Détails
        </button>
      `
      break
  }

  return actions
}

// Créer les informations du prestataire
function createProviderInfo(provider) {
  return `
        <div class="border-t pt-4 mt-4">
            <h4 class="font-semibold text-gray-900 mb-2">Prestataire assigné</h4>
            <div class="flex items-center space-x-3">
                <img src="${provider.avatar || "/placeholder.svg?height=40&width=40&query=provider+avatar"}" 
                     alt="${provider.name}" class="w-10 h-10 rounded-full">
                <div>
                    <p class="font-medium">${provider.name}</p>
                    <div class="flex items-center">
                        <div class="flex text-yellow-400">
                            ${createStarRating(provider.rating)}
                        </div>
                        <span class="text-sm text-gray-600 ml-2">(${provider.rating}/5)</span>
                    </div>
                </div>
                <button onclick="contactProvider('${provider.id}')" class="ml-auto bg-primary text-white px-4 py-2 rounded hover:bg-secondary">
                    Contacter
                </button>
            </div>
        </div>
    `
}

// Créer la section des offres
function createOffersSection(offers) {
  return `
        <div class="border-t pt-4 mt-4">
            <h4 class="font-semibold text-gray-900 mb-3">Offres reçues (${offers.length})</h4>
            <div class="space-y-3">
                ${offers
                  .slice(0, 3)
                  .map(
                    (offer) => `
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded">
                        <div class="flex items-center space-x-3">
                            <img src="${offer.provider.avatar || "/placeholder.svg?height=32&width=32&query=provider+avatar"}" 
                                 alt="${offer.provider.name}" class="w-8 h-8 rounded-full">
                            <div>
                                <p class="font-medium text-sm">${offer.provider.name}</p>
                                <p class="text-xs text-gray-600">${formatPrice(offer.price)}</p>
                            </div>
                        </div>
                        <div class="flex space-x-2">
                            <button onclick="acceptOffer('${offer.id}')" class="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600">
                                Accepter
                            </button>
                            <button onclick="declineOffer('${offer.id}')" class="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600">
                                Refuser
                            </button>
                        </div>
                    </div>
                `,
                  )
                  .join("")}
                ${
                  offers.length > 3
                    ? `
                    <button onclick="viewAllOffers('${offers[0].announcement_id}')" class="text-primary hover:text-secondary text-sm">
                        Voir toutes les offres (${offers.length})
                    </button>
                `
                    : ""
                }
            </div>
        </div>
    `
}

// Utilitaires pour les statuts
function getStatusClass(status) {
  const classes = {
    pending: "bg-yellow-100 text-yellow-800",
    accepted: "bg-blue-100 text-blue-800",
    in_progress: "bg-purple-100 text-purple-800",
    completed: "bg-green-100 text-green-800",
    cancelled: "bg-red-100 text-red-800",
  }
  return classes[status] || "bg-gray-100 text-gray-800"
}

function getStatusText(status) {
  const texts = {
    pending: "En attente",
    accepted: "Acceptée",
    in_progress: "En cours",
    completed: "Terminée",
    cancelled: "Annulée",
  }
  return texts[status] || "Inconnu"
}

// Créer les étoiles de notation
function createStarRating(rating) {
  let stars = ""
  for (let i = 1; i <= 5; i++) {
    if (i <= rating) {
      stars += '<i class="fas fa-star"></i>'
    } else if (i - 0.5 <= rating) {
      stars += '<i class="fas fa-star-half-alt"></i>'
    } else {
      stars += '<i class="far fa-star"></i>'
    }
  }
  return stars
}

// Actions sur les annonces
function openCreateModal() {
  const modal = document.getElementById("announcement-modal")
  const title = document.getElementById("modal-title")
  const form = document.getElementById("announcement-form")

  if (modal && title && form) {
    title.textContent = "Nouvelle annonce"
    form.reset()
    form.dataset.mode = "create"
    modal.classList.remove("hidden")
  }
}

function closeAnnouncementModal() {
  const modal = document.getElementById("announcement-modal")
  if (modal) {
    modal.classList.add("hidden")
  }
}

async function handleAnnouncementSubmit(e) {
  e.preventDefault()

  const form = e.target
  const formData = new FormData(form)
  const data = Object.fromEntries(formData.entries())

  try {
    const isEdit = form.dataset.mode === "edit"
    const endpoint = isEdit ? `/announcements/${form.dataset.id}` : "/announcements"
    const method = isEdit ? "PUT" : "POST"

    const response = await apiCall(endpoint, {
      method: method,
      body: JSON.stringify(data),
    })

    if (response.success) {
      showNotification(isEdit ? "Annonce modifiée avec succès" : "Annonce créée avec succès", "success")
      closeAnnouncementModal()
      await loadAnnouncements(currentPage)
    }
  } catch (error) {
    console.error("Erreur lors de la sauvegarde:", error)
    showNotification("Erreur lors de la sauvegarde", "error")
  }
}

async function editAnnouncement(id) {
  try {
    const announcement = await apiCall(`/announcements/${id}`)

    const modal = document.getElementById("announcement-modal")
    const title = document.getElementById("modal-title")
    const form = document.getElementById("announcement-form")

    if (modal && title && form) {
      title.textContent = "Modifier l'annonce"
      form.dataset.mode = "edit"
      form.dataset.id = id

      // Remplir le formulaire
      Object.keys(announcement).forEach((key) => {
        const input = form.querySelector(`[name="${key}"]`)
        if (input) {
          input.value = announcement[key]
        }
      })

      modal.classList.remove("hidden")
    }
  } catch (error) {
    console.error("Erreur lors du chargement de l'annonce:", error)
    showNotification("Erreur lors du chargement de l'annonce", "error")
  }
}

async function cancelAnnouncement(id) {
  if (!confirm("Êtes-vous sûr de vouloir annuler cette annonce ?")) {
    return
  }

  try {
    const response = await apiCall(`/announcements/${id}/cancel`, {
      method: "POST",
    })

    if (response.success) {
      showNotification("Annonce annulée", "success")
      await loadAnnouncements(currentPage)
    }
  } catch (error) {
    console.error("Erreur lors de l'annulation:", error)
    showNotification("Erreur lors de l'annulation", "error")
  }
}

// Filtres et pagination
function applyFilters() {
  filters = {
    status: document.getElementById("filter-status")?.value || "",
    type: document.getElementById("filter-type")?.value || "",
    date: document.getElementById("filter-date")?.value || "",
  }

  // Supprimer les filtres vides
  Object.keys(filters).forEach((key) => {
    if (!filters[key]) {
      delete filters[key]
    }
  })

  loadAnnouncements(1)
}

function updatePagination() {
  const container = document.getElementById("pagination")
  if (!container) return

  if (totalPages <= 1) {
    container.innerHTML = ""
    return
  }

  let pagination = '<div class="flex space-x-2">'

  // Bouton précédent
  if (currentPage > 1) {
    pagination += `<button onclick="loadAnnouncements(${currentPage - 1})" class="px-3 py-2 border rounded hover:bg-gray-100">Précédent</button>`
  }

  // Numéros de page
  for (let i = Math.max(1, currentPage - 2); i <= Math.min(totalPages, currentPage + 2); i++) {
    const isActive = i === currentPage
    pagination += `
            <button onclick="loadAnnouncements(${i})" 
                    class="px-3 py-2 border rounded ${isActive ? "bg-primary text-white" : "hover:bg-gray-100"}">
                ${i}
            </button>
        `
  }

  // Bouton suivant
  if (currentPage < totalPages) {
    pagination += `<button onclick="loadAnnouncements(${currentPage + 1})" class="px-3 py-2 border rounded hover:bg-gray-100">Suivant</button>`
  }

  pagination += "</div>"
  container.innerHTML = pagination
}

// Actions supplémentaires
async function acceptOffer(offerId) {
  try {
    const response = await apiCall(`/offers/${offerId}/accept`, {
      method: "POST",
    })

    if (response.success) {
      showNotification("Offre acceptée", "success")
      await loadAnnouncements(currentPage)
    }
  } catch (error) {
    console.error("Erreur lors de l'acceptation:", error)
    showNotification("Erreur lors de l'acceptation", "error")
  }
}

// Ouvrir la modal de notation
async function rateService(announcementId) {
  try {
    // Récupérer les détails de l'annonce
    const announcement = await apiCall(`/announcements/${announcementId}`)

    if (!announcement.provider) {
      showNotification("Aucun prestataire assigné à cette annonce", "error")
      return
    }

    // Remplir les informations dans la modal
    document.getElementById("rating-announcement-id").value = announcementId
    document.getElementById("rating-provider-id").value = announcement.provider.id
    document.getElementById("rating-provider-name").textContent = announcement.provider.name
    document.getElementById("rating-provider-avatar").src =
      announcement.provider.avatar || "/placeholder.svg?height=48&width=48&query=provider+avatar"
    document.getElementById("rating-announcement-title").textContent = announcement.title

    // Réinitialiser le formulaire
    resetRatingForm()

    // Afficher la modal
    document.getElementById("rating-modal").classList.remove("hidden")

    // Initialiser les événements de notation
    initializeRatingEvents()
  } catch (error) {
    console.error("Erreur lors du chargement des détails:", error)
    showNotification("Erreur lors du chargement des détails", "error")
  }
}

// Initialiser les événements de notation
function initializeRatingEvents() {
  // Gestion des étoiles principales
  const starButtons = document.querySelectorAll(".star-btn")
  starButtons.forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault()
      const rating = Number.parseInt(btn.dataset.rating)
      setOverallRating(rating)
    })

    btn.addEventListener("mouseenter", () => {
      const rating = Number.parseInt(btn.dataset.rating)
      highlightStars(starButtons, rating)
    })
  })

  // Gestion des étoiles de critères
  const criteriaStars = document.querySelectorAll(".criteria-star")
  criteriaStars.forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault()
      const criteria = btn.dataset.criteria
      const rating = Number.parseInt(btn.dataset.rating)
      setCriteriaRating(criteria, rating)
    })
  })

  // Gestion des pourboires
  const tipButtons = document.querySelectorAll(".tip-btn")
  tipButtons.forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault()
      const tip = btn.dataset.tip
      setTipAmount(tip)
    })
  })

  // Gestion du formulaire
  const form = document.getElementById("rating-form")
  form.addEventListener("submit", handleRatingSubmit)

  // Réinitialiser les highlights au survol
  const starContainer = document.querySelector(".star-btn").parentElement
  starContainer.addEventListener("mouseleave", () => {
    const currentRating = Number.parseInt(document.getElementById("overall-rating").value) || 0
    highlightStars(starButtons, currentRating)
  })
}

// Définir la note globale
function setOverallRating(rating) {
  document.getElementById("overall-rating").value = rating

  const starButtons = document.querySelectorAll(".star-btn")
  highlightStars(starButtons, rating)

  const ratingTexts = {
    1: "Très insatisfait",
    2: "Insatisfait",
    3: "Correct",
    4: "Satisfait",
    5: "Très satisfait",
  }

  document.getElementById("rating-text").textContent = ratingTexts[rating] || "Cliquez sur les étoiles pour noter"
}

// Définir la note d'un critère
function setCriteriaRating(criteria, rating) {
  document.getElementById(`${criteria}-rating`).value = rating
  document.getElementById(`${criteria}-value`).textContent = `${rating}/5`

  const criteriaStars = document.querySelectorAll(`[data-criteria="${criteria}"]`)
  highlightStars(criteriaStars, rating)
}

// Mettre en surbrillance les étoiles
function highlightStars(stars, rating) {
  stars.forEach((star, index) => {
    if (index < rating) {
      star.classList.remove("text-gray-300")
      star.classList.add("text-warning")
    } else {
      star.classList.remove("text-warning")
      star.classList.add("text-gray-300")
    }
  })
}

// Définir le montant du pourboire
function setTipAmount(tip) {
  const tipButtons = document.querySelectorAll(".tip-btn")
  const tipInput = document.getElementById("tip-amount")

  // Réinitialiser les boutons
  tipButtons.forEach((btn) => {
    btn.classList.remove("border-primary", "bg-primary/5")
    btn.classList.add("border-gray-200")
  })

  if (tip === "custom") {
    tipInput.classList.remove("hidden")
    tipInput.focus()
    event.target.classList.add("border-primary", "bg-primary/5")
  } else {
    tipInput.classList.add("hidden")
    tipInput.value = tip
    event.target.classList.add("border-primary", "bg-primary/5")
  }
}

// Gérer la soumission de la notation
async function handleRatingSubmit(e) {
  e.preventDefault()

  const formData = new FormData(e.target)
  const ratingData = Object.fromEntries(formData.entries())

  // Validation
  if (!ratingData.overallRating || ratingData.overallRating < 1) {
    showNotification("Veuillez donner une note globale", "warning")
    return
  }

  try {
    const response = await apiCall("/ratings", {
      method: "POST",
      body: JSON.stringify({
        announcementId: ratingData.announcementId,
        providerId: ratingData.providerId,
        overallRating: Number.parseInt(ratingData.overallRating),
        punctuality: Number.parseInt(ratingData.punctuality) || 0,
        quality: Number.parseInt(ratingData.quality) || 0,
        communication: Number.parseInt(ratingData.communication) || 0,
        comment: ratingData.comment,
        recommend: ratingData.recommend === "yes",
        tip: Number.parseFloat(ratingData.tip) || 0,
      }),
    })

    if (response.success) {
      showNotification("Merci pour votre avis !", "success")
      closeRatingModal()

      // Recharger les annonces pour mettre à jour le statut
      await loadAnnouncements(currentPage)

      // Envoyer une notification au prestataire
      await sendRatingNotification(ratingData.providerId, ratingData.overallRating)
    }
  } catch (error) {
    console.error("Erreur lors de l'envoi de la notation:", error)
    showNotification("Erreur lors de l'envoi de votre avis", "error")
  }
}

// Fermer la modal de notation
function closeRatingModal() {
  document.getElementById("rating-modal").classList.add("hidden")
  resetRatingForm()
}

// Réinitialiser le formulaire de notation
function resetRatingForm() {
  const form = document.getElementById("rating-form")
  form.reset()

  // Réinitialiser les étoiles
  const allStars = document.querySelectorAll(".star-btn, .criteria-star")
  allStars.forEach((star) => {
    star.classList.remove("text-warning")
    star.classList.add("text-gray-300")
  })

  // Réinitialiser les valeurs
  document.getElementById("overall-rating").value = ""
  document.getElementById("rating-text").textContent = "Cliquez sur les étoiles pour noter"

  const criteriaValues = ["punctuality-value", "quality-value", "communication-value"]
  criteriaValues.forEach((id) => {
    document.getElementById(id).textContent = "0/5"
  })

  // Réinitialiser les pourboires
  const tipButtons = document.querySelectorAll(".tip-btn")
  tipButtons.forEach((btn) => {
    btn.classList.remove("border-primary", "bg-primary/5")
    btn.classList.add("border-gray-200")
  })

  document.getElementById("tip-amount").classList.add("hidden")
}

// Envoyer une notification au prestataire
async function sendRatingNotification(providerId, rating) {
  try {
    await apiCall("/notifications", {
      method: "POST",
      body: JSON.stringify({
        recipientId: providerId,
        type: "rating_received",
        title: "Nouvel avis reçu",
        message: `Vous avez reçu une note de ${rating}/5 étoiles`,
        data: {
          rating: rating,
        },
      }),
    })
  } catch (error) {
    console.error("Erreur lors de l'envoi de la notification:", error)
  }
}

// Voir la notation donnée
async function viewRating(ratingId) {
  try {
    const rating = await apiCall(`/ratings/${ratingId}`)

    // Créer une modal pour afficher la notation
    const modal = document.createElement("div")
    modal.className = "fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
    modal.innerHTML = `
      <div class="flex items-center justify-center min-h-screen p-4">
        <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl">
          <div class="text-center mb-6">
            <h3 class="text-xl font-bold text-gray-900 mb-2">Votre avis</h3>
            <div class="flex justify-center space-x-1 mb-4">
              ${createStarRating(rating.overallRating)}
            </div>
            <p class="text-gray-600">Note donnée le ${formatDate(rating.createdAt)}</p>
          </div>
          
          <div class="space-y-4">
            <div class="grid grid-cols-3 gap-4 text-center">
              <div>
                <p class="text-sm text-gray-600">Ponctualité</p>
                <p class="font-semibold">${rating.punctuality}/5</p>
              </div>
              <div>
                <p class="text-sm text-gray-600">Qualité</p>
                <p class="font-semibold">${rating.quality}/5</p>
              </div>
              <div>
                <p class="text-sm text-gray-600">Communication</p>
                <p class="font-semibold">${rating.communication}/5</p>
              </div>
            </div>
            
            ${
              rating.comment
                ? `
              <div class="bg-gray-50 p-4 rounded-xl">
                <p class="text-sm text-gray-700">"${rating.comment}"</p>
              </div>
            `
                : ""
            }
            
            ${
              rating.tip > 0
                ? `
              <div class="text-center text-sm text-gray-600">
                <i class="fas fa-heart text-red-500 mr-1"></i>
                Pourboire donné: ${formatPrice(rating.tip)}
              </div>
            `
                : ""
            }
          </div>
          
          <button onclick="this.parentElement.parentElement.parentElement.remove()" 
                  class="w-full mt-6 bg-primary text-white py-3 rounded-xl hover:bg-secondary transition-colors">
            Fermer
          </button>
        </div>
      </div>
    `

    document.body.appendChild(modal)
  } catch (error) {
    console.error("Erreur lors du chargement de la notation:", error)
    showNotification("Erreur lors du chargement de la notation", "error")
  }
}

// Recommander le même service
async function reorderService(announcementId) {
  try {
    const announcement = await apiCall(`/announcements/${announcementId}`)

    // Pré-remplir le formulaire de création avec les données de l'annonce
    openCreateModal()

    // Remplir les champs
    setTimeout(() => {
      document.getElementById("title").value = announcement.title
      document.getElementById("description").value = announcement.description
      document.getElementById("pickup_address").value = announcement.pickup_address
      document.getElementById("delivery_address").value = announcement.delivery_address
      document.getElementById("price").value = announcement.price
      document.getElementById("weight").value = announcement.weight

      // Sélectionner le type
      const typeRadio = document.querySelector(`input[name="type"][value="${announcement.type}"]`)
      if (typeRadio) {
        typeRadio.checked = true
        typeRadio.parentElement.classList.add("peer-checked:border-primary", "peer-checked:bg-primary/5")
      }

      showNotification("Formulaire pré-rempli avec les données précédentes", "info")
    }, 100)
  } catch (error) {
    console.error("Erreur lors du chargement de l'annonce:", error)
    showNotification("Erreur lors du chargement des données", "error")
  }
}

// Suivre la livraison en temps réel
function trackDelivery(announcementId) {
  // Ouvrir une nouvelle fenêtre ou modal de suivi
  window.open(`tracking.html?id=${announcementId}`, "_blank", "width=800,height=600")
}

// Voir la raison d'annulation
async function viewCancellationReason(announcementId) {
  try {
    const details = await apiCall(`/announcements/${announcementId}/cancellation`)

    const modal = document.createElement("div")
    modal.className = "fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
    modal.innerHTML = `
      <div class="flex items-center justify-center min-h-screen p-4">
        <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl">
          <div class="text-center mb-6">
            <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <i class="fas fa-times text-red-500 text-2xl"></i>
            </div>
            <h3 class="text-xl font-bold text-gray-900 mb-2">Annulation</h3>
            <p class="text-gray-600">Annulée le ${formatDate(details.cancelledAt)}</p>
          </div>
          
          <div class="space-y-4">
            <div>
              <p class="text-sm font-medium text-gray-700 mb-2">Raison:</p>
              <p class="text-gray-900">${details.reason}</p>
            </div>
            
            ${
              details.comment
                ? `
              <div>
                <p class="text-sm font-medium text-gray-700 mb-2">Commentaire:</p>
                <div class="bg-gray-50 p-3 rounded-lg">
                  <p class="text-sm text-gray-700">${details.comment}</p>
                </div>
              </div>
            `
                : ""
            }
            
            ${
              details.refundAmount > 0
                ? `
              <div class="bg-green-50 p-3 rounded-lg">
                <p class="text-sm text-green-700">
                  <i class="fas fa-check-circle mr-1"></i>
                  Remboursement: ${formatPrice(details.refundAmount)}
                </p>
              </div>
            `
                : ""
            }
          </div>
          
          <button onclick="this.parentElement.parentElement.parentElement.remove()" 
                  class="w-full mt-6 bg-primary text-white py-3 rounded-xl hover:bg-secondary transition-colors">
            Fermer
          </button>
        </div>
      </div>
    `

    document.body.appendChild(modal)
  } catch (error) {
    console.error("Erreur lors du chargement des détails:", error)
    showNotification("Erreur lors du chargement des détails", "error")
  }
}
