import { Chart } from "@/components/ui/chart"
// Gestion du dashboard
let dashboardData = {}
const charts = {}

// Initialisation du dashboard
document.addEventListener("DOMContentLoaded", () => {
  if (getCurrentPage() === "dashboard") {
    initializeDashboard()
  }
})

async function initializeDashboard() {
  try {
    await loadDashboardData()
    initializeCharts()
    updateDashboardDisplay()

    // Actualiser les données toutes les 5 minutes
    setInterval(loadDashboardData, 5 * 60 * 1000)
  } catch (error) {
    console.error("Erreur lors de l'initialisation du dashboard:", error)
    showNotification("Erreur lors du chargement du dashboard", "error")
  }
}

// Charger les données du dashboard
async function loadDashboardData() {
  try {
    const period = document.getElementById("period-selector")?.value || 30

    const response = await apiCall(`/dashboard/stats?period=${period}`)
    dashboardData = response.data

    updateDashboardDisplay()
    updateCharts()
  } catch (error) {
    console.error("Erreur lors du chargement des données:", error)
  }
}

// Mettre à jour l'affichage du dashboard
function updateDashboardDisplay() {
  if (!dashboardData) return

  // Statistiques principales
  updateElement("total-announcements", dashboardData.totalAnnouncements || 0)
  updateElement("successful-deliveries", dashboardData.successfulDeliveries || 0)
  updateElement("total-savings", formatPrice(dashboardData.totalSavings || 0))
  updateElement("eco-points-total", dashboardData.ecoPoints || 0)

  // Croissance
  updateElement("announcements-growth", `${dashboardData.announcementsGrowth || 0}%`)
  updateElement("deliveries-growth", `${dashboardData.deliveriesGrowth || 0}%`)
  updateElement("savings-growth", `${dashboardData.savingsGrowth || 0}%`)

  // Taux de réussite
  updateSuccessRates()

  // Activité récente
  updateRecentActivity()

  // Prestataires favoris
  updateFavoriteProviders()

  // Objectifs
  updateGoals()
}

// Mettre à jour les taux de réussite
function updateSuccessRates() {
  const deliveryRate = dashboardData.deliverySuccessRate || 0
  const serviceRate = dashboardData.serviceSuccessRate || 0

  updateElement("delivery-success-rate", `${deliveryRate}%`)
  updateElement("service-success-rate", `${serviceRate}%`)

  const deliveryProgress = document.getElementById("delivery-progress")
  const serviceProgress = document.getElementById("service-progress")

  if (deliveryProgress) deliveryProgress.style.width = `${deliveryRate}%`
  if (serviceProgress) serviceProgress.style.width = `${serviceRate}%`
}

// Mettre à jour l'activité récente
function updateRecentActivity() {
  const container = document.getElementById("recent-activity")
  if (!container || !dashboardData.recentActivity) return

  if (dashboardData.recentActivity.length === 0) {
    container.innerHTML = `
      <div class="text-center py-8 text-gray-500">
        <i class="fas fa-inbox text-4xl mb-4"></i>
        <p>Aucune activité récente</p>
      </div>
    `
    return
  }

  container.innerHTML = dashboardData.recentActivity
    .slice(0, 5)
    .map((activity) => createActivityItem(activity))
    .join("")
}

// Créer un élément d'activité
function createActivityItem(activity) {
  const iconClass = getActivityIcon(activity.type)
  const colorClass = getActivityColor(activity.type)

  return `
    <div class="flex items-center space-x-4 p-4 border border-gray-100 rounded-xl hover:bg-gray-50 transition-colors">
      <div class="w-10 h-10 ${colorClass} rounded-full flex items-center justify-center">
        <i class="${iconClass} text-white"></i>
      </div>
      <div class="flex-1">
        <p class="font-medium text-gray-900">${activity.title}</p>
        <p class="text-sm text-gray-600">${activity.description}</p>
        <p class="text-xs text-gray-500">${formatDate(activity.createdAt)}</p>
      </div>
      <div class="text-right">
        <span class="text-sm font-medium ${getStatusColor(activity.status)}">${getStatusText(activity.status)}</span>
      </div>
    </div>
  `
}

// Mettre à jour les prestataires favoris
function updateFavoriteProviders() {
  const container = document.getElementById("favorite-providers")
  if (!container || !dashboardData.favoriteProviders) return

  if (dashboardData.favoriteProviders.length === 0) {
    container.innerHTML = `
      <div class="text-center py-4 text-gray-500">
        <p class="text-sm">Aucun prestataire favori</p>
      </div>
    `
    return
  }

  container.innerHTML = dashboardData.favoriteProviders
    .slice(0, 3)
    .map(
      (provider) => `
      <div class="flex items-center space-x-3">
        <img src="${provider.avatar || "/placeholder.svg?height=32&width=32&query=provider+avatar"}" 
             alt="${provider.name}" class="w-8 h-8 rounded-full">
        <div class="flex-1">
          <p class="font-medium text-sm">${provider.name}</p>
          <div class="flex items-center">
            <div class="flex text-yellow-400 text-xs">
              ${createStarRating(provider.rating)}
            </div>
            <span class="text-xs text-gray-500 ml-1">(${provider.rating})</span>
          </div>
        </div>
        <span class="text-xs text-gray-500">${provider.completedJobs} jobs</span>
      </div>
    `,
    )
    .join("")
}

// Mettre à jour les objectifs
function updateGoals() {
  const goals = dashboardData.goals || {}

  // Objectif annonces
  const announcementsCurrent = goals.announcements?.current || 0
  const announcementsTarget = goals.announcements?.target || 10
  const announcementsProgress = Math.min((announcementsCurrent / announcementsTarget) * 100, 100)

  updateElement("goal-announcements-current", announcementsCurrent)
  updateElement("goal-announcements-target", announcementsTarget)

  const announcementsProgressBar = document.getElementById("goal-announcements-progress")
  if (announcementsProgressBar) {
    announcementsProgressBar.style.width = `${announcementsProgress}%`
  }

  // Objectif points éco
  const ecoCurrent = goals.ecoPoints?.current || 0
  const ecoTarget = goals.ecoPoints?.target || 100
  const ecoProgress = Math.min((ecoCurrent / ecoTarget) * 100, 100)

  updateElement("goal-eco-current", ecoCurrent)
  updateElement("goal-eco-target", ecoTarget)

  const ecoProgressBar = document.getElementById("goal-eco-progress")
  if (ecoProgressBar) {
    ecoProgressBar.style.width = `${ecoProgress}%`
  }
}

// Initialiser les graphiques
function initializeCharts() {
  initializeAnnouncementsChart()
  initializeTypesChart()
}

// Graphique des annonces
function initializeAnnouncementsChart() {
  const ctx = document.getElementById("announcements-chart")
  if (!ctx) return

  charts.announcements = new Chart(ctx, {
    type: "line",
    data: {
      labels: [],
      datasets: [
        {
          label: "Annonces créées",
          data: [],
          borderColor: "#6366f1",
          backgroundColor: "rgba(99, 102, 241, 0.1)",
          tension: 0.4,
          fill: true,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false,
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          grid: {
            color: "rgba(0, 0, 0, 0.05)",
          },
        },
        x: {
          grid: {
            color: "rgba(0, 0, 0, 0.05)",
          },
        },
      },
    },
  })
}

// Graphique des types
function initializeTypesChart() {
  const ctx = document.getElementById("types-chart")
  if (!ctx) return

  charts.types = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: ["Livraison", "Service", "Récupération", "Express"],
      datasets: [
        {
          data: [0, 0, 0, 0],
          backgroundColor: ["#6366f1", "#8b5cf6", "#06b6d4", "#10b981"],
          borderWidth: 0,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: "bottom",
          labels: {
            padding: 20,
            usePointStyle: true,
          },
        },
      },
    },
  })
}

// Mettre à jour les graphiques
function updateCharts() {
  if (!dashboardData.chartData) return

  // Mettre à jour le graphique des annonces
  if (charts.announcements && dashboardData.chartData.announcements) {
    charts.announcements.data.labels = dashboardData.chartData.announcements.labels
    charts.announcements.data.datasets[0].data = dashboardData.chartData.announcements.data
    charts.announcements.update()
  }

  // Mettre à jour le graphique des types
  if (charts.types && dashboardData.chartData.types) {
    charts.types.data.datasets[0].data = dashboardData.chartData.types.data
    charts.types.update()
  }
}

// Changer le type de graphique
function changeChartType(chartName, type) {
  if (!charts[chartName]) return

  charts[chartName].config.type = type
  charts[chartName].update()

  // Mettre à jour les boutons
  const buttons = document.querySelectorAll(`button[onclick*="${chartName}"]`)
  buttons.forEach((btn) => {
    btn.className = btn.onclick.toString().includes(`'${type}'`)
      ? "px-3 py-1 text-sm bg-primary text-white rounded-lg"
      : "px-3 py-1 text-sm bg-gray-200 text-gray-700 rounded-lg"
  })
}

// Exporter les données
async function exportData() {
  try {
    const period = document.getElementById("period-selector")?.value || 30

    const response = await fetch(`${API_BASE_URL}/dashboard/export?period=${period}`, {
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    })

    if (response.ok) {
      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `dashboard-export-${new Date().toISOString().split("T")[0]}.pdf`
      a.click()
      window.URL.revokeObjectURL(url)

      showNotification("Export réussi", "success")
    }
  } catch (error) {
    console.error("Erreur lors de l'export:", error)
    showNotification("Erreur lors de l'export", "error")
  }
}

// Utilitaires
function getActivityIcon(type) {
  const icons = {
    announcement: "fas fa-bullhorn",
    delivery: "fas fa-truck",
    service: "fas fa-tools",
    payment: "fas fa-credit-card",
    rating: "fas fa-star",
  }
  return icons[type] || "fas fa-info-circle"
}

function getActivityColor(type) {
  const colors = {
    announcement: "bg-primary",
    delivery: "bg-success",
    service: "bg-secondary",
    payment: "bg-warning",
    rating: "bg-accent",
  }
  return colors[type] || "bg-gray-500"
}

function getStatusColor(status) {
  const colors = {
    pending: "text-warning",
    completed: "text-success",
    cancelled: "text-danger",
    in_progress: "text-primary",
  }
  return colors[status] || "text-gray-500"
}

// Gestionnaire de changement de période
document.addEventListener("change", (e) => {
  if (e.target.id === "period-selector") {
    loadDashboardData()
  }
})

// Mock functions to resolve errors
function formatDate(date) {
  return date
}

function getStatusText(status) {
  return status
}

function createStarRating(rating) {
  return rating
}

const API_BASE_URL = ""
const authToken = ""
