// Configuration API
const API_BASE_URL = "http://api:4000/api" // À adapter selon votre backend

// Gestion de l'authentification
let currentUser = null
let authToken = localStorage.getItem("authToken")

// Initialisation
document.addEventListener("DOMContentLoaded", () => {
  initializeApp()
})

async function initializeApp() {
  // Vérifier l'authentification
  if (authToken) {
    try {
      currentUser = await getCurrentUser()
      updateUserInterface()
    } catch (error) {
      console.error("Erreur lors de la récupération de l'utilisateur:", error)
      logout()
    }
  }

  // Initialiser les événements
  initializeEventListeners()

  // Charger les données de la page actuelle
  loadPageData()
}

function initializeEventListeners() {
  // Menu mobile
  const mobileMenuBtn = document.getElementById("mobile-menu-btn")
  const mobileMenu = document.getElementById("mobile-menu")

  if (mobileMenuBtn && mobileMenu) {
    mobileMenuBtn.addEventListener("click", () => {
      mobileMenu.classList.toggle("hidden")
    })
  }

  // Menu profil
  const profileBtn = document.getElementById("profile-btn")
  const profileMenu = document.getElementById("profile-menu")

  if (profileBtn && profileMenu) {
    profileBtn.addEventListener("click", (e) => {
      e.stopPropagation()
      profileMenu.classList.toggle("hidden")
    })

    // Fermer le menu en cliquant ailleurs
    document.addEventListener("click", () => {
      profileMenu.classList.add("hidden")
    })
  }

  // Panier
  const cartBtn = document.getElementById("cart-btn")
  if (cartBtn) {
    cartBtn.addEventListener("click", openCart)
  }
}

// Fonctions API
async function apiCall(endpoint, options = {}) {
  const url = `${API_BASE_URL}${endpoint}`
  const defaultOptions = {
    headers: {
      "Content-Type": "application/json",
      ...(authToken && { Authorization: `Bearer ${authToken}` }),
    },
  }

  const response = await fetch(url, { ...defaultOptions, ...options })

  if (!response.ok) {
    if (response.status === 401) {
      logout()
      throw new Error("Non autorisé")
    }
    throw new Error(`Erreur API: ${response.status}`)
  }

  return response.json()
}

async function getCurrentUser() {
  return await apiCall("/auth/me")
}

async function getUserStats() {
  return await apiCall("/users/stats")
}

// Gestion de l'authentification
function logout() {
  localStorage.removeItem("authToken")
  authToken = null
  currentUser = null
  window.location.href = "login.html"
}

function updateUserInterface() {
  if (currentUser) {
    const userNameElement = document.getElementById("user-name")
    if (userNameElement) {
      userNameElement.textContent = currentUser.name || "Client"
    }
  }
}

// Chargement des données selon la page
async function loadPageData() {
  const currentPage = getCurrentPage()

  switch (currentPage) {
    case "index":
      await loadDashboardStats()
      break
    case "annonces":
      await loadAnnouncements()
      break
    case "dashboard":
      await loadFullDashboard()
      break
    case "historique":
      await loadHistory()
      break
    case "abonnements":
      await loadSubscriptions()
      break
  }
}

function getCurrentPage() {
  const path = window.location.pathname
  const page = path.split("/").pop().split(".")[0]
  return page || "index"
}

// Chargement des statistiques pour la page d'accueil
async function loadDashboardStats() {
  try {
    const stats = await getUserStats()

    // Mettre à jour les statistiques
    updateElement("total-deliveries", stats.totalDeliveries || 0)
    updateElement("total-spent", `${stats.totalSpent || 0}€`)
    updateElement("avg-rating", stats.averageRating || 0)
    updateElement("eco-points", stats.ecoPoints || 0)
  } catch (error) {
    console.error("Erreur lors du chargement des statistiques:", error)
  }
}

// Utilitaires
function updateElement(id, content) {
  const element = document.getElementById(id)
  if (element) {
    element.textContent = content
  }
}

function showNotification(message, type = "info") {
  // Créer une notification toast
  const notification = document.createElement("div")
  notification.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg max-w-sm ${getNotificationClasses(type)}`
  notification.innerHTML = `
        <div class="flex items-center">
            <i class="fas ${getNotificationIcon(type)} mr-3"></i>
            <span>${message}</span>
            <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-lg">&times;</button>
        </div>
    `

  document.body.appendChild(notification)

  // Supprimer automatiquement après 5 secondes
  setTimeout(() => {
    if (notification.parentElement) {
      notification.remove()
    }
  }, 5000)
}

function getNotificationClasses(type) {
  switch (type) {
    case "success":
      return "bg-green-500 text-white"
    case "error":
      return "bg-red-500 text-white"
    case "warning":
      return "bg-yellow-500 text-white"
    default:
      return "bg-blue-500 text-white"
  }
}

function getNotificationIcon(type) {
  switch (type) {
    case "success":
      return "fa-check-circle"
    case "error":
      return "fa-exclamation-circle"
    case "warning":
      return "fa-exclamation-triangle"
    default:
      return "fa-info-circle"
  }
}

// Fonctions globales
function openProviderSearch() {
  // Ouvrir une modal de recherche de prestataires
  showNotification("Fonction de recherche de prestataires en développement", "info")
}

// Formatage des dates
function formatDate(dateString) {
  const date = new Date(dateString)
  return date.toLocaleDateString("fr-FR", {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  })
}

// Formatage des prix
function formatPrice(price) {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR",
  }).format(price)
}

// Déclarations des fonctions manquantes (à adapter selon l'implémentation réelle)
async function openCart() {
  showNotification("Fonctionnalité du panier en développement", "info")
}

async function loadAnnouncements() {
  showNotification("Chargement des annonces...", "info")
}

async function loadFullDashboard() {
  showNotification("Chargement complet du tableau de bord...", "info")
}

async function loadHistory() {
  showNotification("Chargement de l'historique...", "info")
}

async function loadSubscriptions() {
  showNotification("Chargement des abonnements...", "info")
}
